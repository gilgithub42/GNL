//Creation get_next_line

#include <stdlib.h>
#include <sys/types.h>
//#include <sys/uio.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include "/Users/gigregoi/Desktop/gigregoi/libft/rendu1/libft.h"
#include "get_next_line.h"
int getnextline_(const int fd, char **line);

int main(int argc, char **argv)
{
	int     fd;
	char    *line;
//	int     ret;

	line = NULL;
	if(argc < 2)
		return 0;
//	ret = 0;

if ((fd = open(argv[1],O_RDONLY))> 0)
{
	while(get_next_line(fd,&line))
	{
		printf("Boucle:%sFIN\n",line);
		ft_strdel(&line);
	}
	printf("Derniere ligne : %sFIN", line);

		ft_strdel(&line);
		close(fd);
	}
		else if ((fd = open(argv[1],O_RDONLY))< 0)
	{
		printf("Entree standard \n");
		
		// scanf("%s", argv[1]);
		fd = 0;
		get_next_line(fd,&line);
		printf("Boucle:%sFIN\n",line);
		ft_strdel(&line);
	}
	return(0);
}
