/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: drouille <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/03 14:51:23 by drouille          #+#    #+#             */
/*   Updated: 2020/07/02 16:41:36 by gigregoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include "libft/includes/libft.h"
#include "get_next_line.h"

static int	add_chars_to_buf(char **fdg, int fd, char *buf)
{
	char	*pc;

	if (!fdg[fd])
	{
		if (!(fdg[fd] = ft_strdup(buf)))
			return (-1);
	}
	else
	{
		if (!(pc = ft_strjoin(fdg[fd], buf)))
			return (-1);
		free(fdg[fd]);
		fdg[fd] = pc;
	}
	return (0);
}

static int	findeol_chars_subst(char **fdg, int fd)
{
	int i;

	i = 0;
	while (fdg[fd][i] != '\n' && fdg[fd][i] != 0)
	{
		if (!ft_isprint(fdg[fd][i]) && fdg[fd][i] != 9)
			fdg[fd][i] = '\\';
		i++;
	}
	return (i);
}

static int	check_buf_line(char **fdg, int fd, char **line)
{
	int		i;
	char	*p;

	i = findeol_chars_subst(fdg, fd);
	if (fdg[fd][i] == '\n')
	{
		if (!(*line = ft_strsub(fdg[fd], 0, i)))
			return (-1);
		if (!(p = ft_strdup(&fdg[fd][i + 1])))
			return (-1);
		free(fdg[fd]);
		fdg[fd] = p;
		if (fdg[fd][0] == 0)
			ft_strdel(&fdg[fd]);
	}
	else if (!fdg[fd][i])
	{
		*line = ft_strdup(fdg[fd]);
		ft_strdel(&fdg[fd]);
	}
	return (1);
}

int			get_next_line(const int fd, char **line)
{
	static char	*fdg[1024];
	char		buf[BUFF_SIZE + 1];
	int			nbc;
	int			ind;

	if (fd < 0 || line == NULL)
		return (-1);
	ind = fd;
	if (fd > 1023)
		ind = 1000;
	while ((nbc = read(fd, buf, BUFF_SIZE)) > 0)
	{
		buf[nbc] = 0;
		if (add_chars_to_buf(fdg, ind, buf))
			return (-1);
		if (ft_strchr(buf, '\n'))
			break ;
	}
	if (nbc < 0)
		return (-1);
	if (!nbc && (!fdg[ind] || fdg[ind][0] == 0))
		return (0);
	return (check_buf_line(fdg, ind, line));
}
