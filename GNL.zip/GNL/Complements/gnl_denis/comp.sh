set -x
norminette get_next_line.[ch] libft/*.[ch] libft/includes/libft.h
make -C libft/ fclean && make -C libft/
clang -Wall -Wextra -Werror -DBUFF_SIZE=50000 -I libft/includes -o get_next_line.o -c get_next_line.c
clang -Wall -Wextra -Werror -DBUFF_SIZE=50000 -I libft/includes -o main.o -c main.c
clang -o test_gnl main.o get_next_line.o -I libft/includes -L libft/ -lft
echo "====================================================================================="
echo "Read and return a line of 8 characters ending by \n included from the standard output"
./test_gnl "totototo\ntotototo\n"
