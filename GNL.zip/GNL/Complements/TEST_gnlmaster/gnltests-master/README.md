# gnltests
Unit tests for get_next_line

Very basic tests atm, I plan to develop these during my years at 42.

Place your get_next_line files next to this repo like this
```./
gnl/
gnltests/
```

gnl7_2.txt & gnl7_3.txt are from juthomas's [file checker](https://github.com/juthomas/filechecker)

Make f to make re and launch the tests
