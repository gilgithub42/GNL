/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gigregoi <gigregoi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/10 16:47:00 by gigregoi          #+#    #+#             */
/*   Updated: 2020/08/25 14:06:07 by gigregoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include "libft.h"
#include "get_next_line.h"

static int	appendbuf(char **p, char *buf)
{
	char	*pc;

	if (!*p)
	{
		if (!(*p = ft_strdup(buf)))
			return (-1);
	}
	else
	{
		if (!(pc = ft_strjoin(*p, buf)))
			return (-1);
		free(*p);
		*p = pc;
	}
	return (0);
}

static int	cutend(char **mot_search, char **line)
{
	int		i;
	char	*p;

	i = 0;
	while ((*mot_search)[i] != '\n' \
			&& (*mot_search)[i] != '\0')
		i++;
	if ((*mot_search)[i] == '\n')
	{
		if (!(*line = ft_strsub(*mot_search, 0, i)))
			return (-1);
		if (!(p = ft_strdup((*mot_search) + i + 1)))
			return (-1);
		free(*mot_search);
		*mot_search = p;
		if ((*mot_search)[0] == 0)
			ft_strdel(mot_search);
	}
	else if (!(*mot_search)[i])
	{
		*line = ft_strdup(*mot_search);
		ft_strdel(mot_search);
	}
	return (1);
}

int			get_next_line(const int fd, char **line)
{
	static char		*mot_search;
	char			buf[BUFF_SIZE + 1];
	int				ret;

	if (fd < 0 || line == NULL || (ret = read(fd, buf, 0)) < 0)
		return (-1);
	if (!mot_search)
		if (!(mot_search = ft_strnew(0)))
			return (-1);
	while (!(ft_strchr(mot_search, '\n')) && \
			(ret = read(fd, buf, BUFF_SIZE)) > 0)
	{
		buf[ret] = 0;
		if (appendbuf(&mot_search, buf))
			return (-1);
	}
	if (ret < 0)
		return (-1);
	if (!(ret) && (!mot_search || \
				mot_search[0] == 0))
		{
			free(mot_search);
			printf("%s free mot_search final = %p\n%s", ORANGE, mot_search, WHITE);
			return (0);
		}
	return (cutend(&mot_search, line));
}
