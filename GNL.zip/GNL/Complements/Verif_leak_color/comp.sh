# set -x
# norminette get_next_line.[ch] libft/*.[ch] libft/includes/libft.h
# make -C libft/ fclean && make -C libft/
clang -Wall -Wextra -Werror -DBUFF_SIZE=8 -I libft/includes -o get_next_line.o -c get_next_line.c
clang -Wall -Wextra -Werror -DBUFF_SIZE=8 -I libft/includes -o main.o -c main.c
clang -o test_gnl main.o get_next_line.o -I libft/includes -L libft/ -lft
echo "========== Buff size = 8 - Lecture en sortie standard de ligne de taille 8 =========="
echo "====================================================================================="
echo "Read and return a line of 8 characters ending by \n included from the standard output"
cat stdin8carat1line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return 2 lines of 8 characters ending by \n included from the standard output"
cat stdin8carat1line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return n lines of 8 characters ending by \n included from the standard output"
cat stdin8caratNlines.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "+++++++++++++++ Meme Lecture dans un fichier +++++++++++++++++++++++++++++++++++++++ "
echo "Read and return a line of 8 characters ending by \n included from the standard output"
./test_gnl stdin8carat1line.txt
echo "====================================================================================="
echo "Read and return 2 lines of 8 characters ending by \n included from the standard output"
./test_gnl stdin8carat1line.txt
echo "====================================================================================="
echo "Read and return n lines of 8 characters ending by \n included from the standard output"
./test_gnl stdin8caratNlines.txt
echo "******************* Middle Tests ****************************************************"
clang -Wall -Wextra -Werror -DBUFF_SIZE=8 -I libft/includes -o get_next_line.o -c get_next_line.c
clang -Wall -Wextra -Werror -DBUFF_SIZE=8 -I libft/includes -o main.o -c main.c
clang -o test_gnl main.o get_next_line.o -I libft/includes -L libft/ -lft
echo "========== Buff size = 16 - Lecture d]un fichier de ligne de taille 8 ==============="
echo "Read and return a line of 16 characters ending by \n included from a file"
./test_gnl stdin16carat1line.txt
echo "====================================================================================="
echo "Read and return 2 line of 16 characters ending by \n included from a file"
./test_gnl stdin16carat2line.txt
echo "====================================================================================="
echo "Read and return a line of 4 characters ending by \n included from a file"
./test_gnl stdin16caratNlines.txt
echo "+++++++++++++++ Meme Lecture a partir de la sortie standrd ++++++++++++++++++++++++++ "
echo "Read and return a line of 16 characters ending by \n included from the standard output"
cat stdin16carat1line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return 2 lines of 8 characters ending by \n included from the standard output"
cat stdin16carat2line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return n lines of 8 characters ending by \n included from the standard output"
cat stdin16caratNlines.txt | ./test_gnl "entree standard"
echo "******************* Advanced Tests ****************************************************"
echo "========== Buff size = 16 - Lecture d]un fichier de ligne de taille 4 ==============="
echo "Read and return a line of 4 characters ending by \n included from a file"
./test_gnl stdin4carat1line.txt
echo "====================================================================================="
echo "Read and return 2 line of 4 characters ending by \n included from a file"
./test_gnl stdin4carat2line.txt
echo "====================================================================================="
echo "Read and return a line of N characters ending by \n included from a file"
./test_gnl stdin4caratNlines.txt
echo "+++++++++++++++ Meme Lecture a partir de la sortie standard ++++++++++++++++++++++++++ "
echo "Read and return a line of 4 characters ending by \n included from the standard output"
cat stdin4carat1line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return 2 lines of 4 characters ending by \n included from the standard output"
cat stdin4carat2line.txt | ./test_gnl "entree standard"
echo "====================================================================================="
echo "Read and return n lines of 4 characters ending by \n included from the standard output"
cat stdin4caratNlines.txt | ./test_gnl "entree standard"
echo "========== Buff size = 16 - Lecture d]un fichier sans \n ============================"
echo "Read and return a line of 4 characters without \n included from a file"
./test_gnl stdin4carat1lineNobsn.txt
echo "====================================================================================="
echo "Read and return 1 line of 8 characters without \n included from a file"
./test_gnl stdin8carat1lineNobsn.txt
echo "====================================================================================="
echo "Read and return 1 line of 16 characters without \n included from a file"
./test_gnl stdin16carat1lineNobsn.txt
echo "====================================================================================="
echo "Read and return an empty line from a file"
./test_gnl emptyline.txt
echo "================Pass an arbitrary file descriptor to the get_next_line function
 on which it is not possible to read, for example 42. The function must return -1 ========="
./test_gnl "42"
echo " ======== Set BUFF_SIZE to 1, 32, 9999 then 10000000 ================================"
clang -Wall -Wextra -Werror -DBUFF_SIZE=9999 -I libft/includes -o get_next_line.o -c get_next_line.c
clang -Wall -Wextra -Werror -DBUFF_SIZE=9999 -I libft/includes -o main.o -c main.c
clang -o test_gnl main.o get_next_line.o -I libft/includes -L libft/ -lft
cat stdin4carat1line.txt | ./test_gnl "entree standard"