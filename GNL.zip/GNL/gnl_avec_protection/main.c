/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gigregoi <gigregoi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/08/07 16:15:16 by gigregoi          #+#    #+#             */
/*   Updated: 2020/08/07 16:15:16 by gigregoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//Creation get_next_line

#include <stdlib.h>
#include <sys/types.h>
//#include <sys/uio.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include "libft/includes/libft.h"
#include "get_next_line.h"
int getnextline_(const int fd, char **line);

int main(int argc, char **argv)
{
	int     fd;
	char    *line;
//	int     ret;

	line = NULL;
	if(argc < 2)
		{
		printf("Ni entree standard ni fichier existant \n");
		return 0;
		}
//	ret = 0;

	if ((fd = open(argv[1],O_RDONLY))> 0)
	{
		while(get_next_line(fd,&line))
		{
			printf("Boucle:%sFIN\n",line);
			ft_strdel(&line);
		}
		// printf("Derniere ligne : %sFIN\n", line);
		ft_strdel(&line);
		close(fd);
	}
	else if ((ft_strcmp(argv[1], "42") != 0) && (fd = open(argv[1],O_RDONLY))< 0)
	{
		printf("Entree standard \n");
		
		fd = 0;
		while (get_next_line(fd,&line))
			{
			printf("Boucle:%sFIN\n",line);
			ft_strdel(&line);
			}
	}
	else if (!ft_strcmp(argv[1], "42"))
	{
		// printf("argv1 = %s", argv[1]);
		printf("arbitrary file descriptor : %d\n", get_next_line(42,&line));
	}
	// system("leaks test_gnl");
	return(0);
}
