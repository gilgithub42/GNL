#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

#include "get_next_line.h"
int main(int argc, char **argv)
{
	int fd[10];
	int eof[10];
	char *line;
	int ret;
	int i = 0;
	int sum = 0;

	while (i < 11)
		eof[i++] = 1;
	i = 0;
	if(argc < 2)
		return 0;
	while(i <argc){
	fd[i] = open(argv[i+1],O_RDONLY);
	i++;
	}
	sum = i-1;
	printf("Nombre de fichiers ouverts = %d\n", sum);
	i = 0;
	int tot = 0;
	while(tot != sum)
	{	
		if ((ret = get_next_line(fd[i],&line))== 0)
			{
			tot += eof[i];
			eof[i] = 0;
			printf("i %d: lecture du fichier terminé\n", i);
			}
		else
		{
			printf("i %d: Boucle====================:%s*%lu\n", i, line,ft_strlen(line));
			free(line);
		}
		i++;
		i%=(argc-1);
	}
	// if(!ret)
	// 	printf("Fin:%s\nFIN\n",line);
	// printf("INFO BUFF_SIZE:%d ret:%d\n",BUFF_SIZE,ret);
	system("leaks test_gnl");
	return 0;
}